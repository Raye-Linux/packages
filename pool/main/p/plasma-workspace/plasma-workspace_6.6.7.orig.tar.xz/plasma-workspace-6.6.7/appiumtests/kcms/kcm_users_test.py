#!/usr/bin/env python3

# SPDX-FileCopyrightText: 2022 Harald Sitter <sitter@kde.org>
# SPDX-FileCopyrightText: 2023 Fushan Wen <qydwhotmail@gmail.com>
# SPDX-License-Identifier: MIT

import subprocess
import time
import unittest
from typing import Final

from appium import webdriver
from appium.options.common.base import AppiumOptions
from appium.webdriver.common.appiumby import AppiumBy

KDE_VERSION: Final = 6
KCM_ID: Final = "kcm_users"


class KCMUsersTest(unittest.TestCase):
    """
    Tests for kcm_users
    """

    driver: webdriver.Remote

    @classmethod
    def setUpClass(cls) -> None:
        """
        Opens the KCM and initialize the webdriver
        """
        options = AppiumOptions()
        options.set_capability("app", f"kcmshell{KDE_VERSION} {KCM_ID}")
        options.set_capability("timeouts", {'implicit': 10000})
        options.set_capability("environ", {
            "LC_ALL": "en_US.UTF-8",
        })
        cls.driver = webdriver.Remote(command_executor='http://127.0.0.1:4723', options=options)

    def tearDown(self) -> None:
        """
        Take screenshot when the current test fails
        """
        if not self._outcome.result.wasSuccessful():
            self.driver.get_screenshot_as_file(f"failed_test_shot_{KCM_ID}_#{self.id()}.png")

    @classmethod
    def tearDownClass(cls) -> None:
        """
        Make sure to terminate the driver again, lest it dangles.
        """
        cls.driver.find_element(AppiumBy.XPATH, "//*[@name='Close' and contains(@accessibility-id, 'Button')]").click()
        for _ in range(10):
            try:
                subprocess.check_call(["pidof", f"kcmshell{KDE_VERSION}"])
            except subprocess.CalledProcessError:
                break
            time.sleep(1)
        cls.driver.quit()

    def test_0_open(self) -> None:
        """
        Tests the KCM can be opened
        """
        self.driver.find_element(AppiumBy.NAME, "Add New User…")
        self.driver.find_element(AppiumBy.NAME, "Name:")
        self.driver.find_element(AppiumBy.NAME, "Change Password")
        self.driver.find_element(AppiumBy.NAME, "Delete User…")

    def test_1_pictures_sheet_1_open(self) -> None:
        """
        Opens the avatar sheet
        """
        self.driver.find_element(AppiumBy.NAME, "Change avatar").click()
        self.driver.find_element(AppiumBy.NAME, "Choose File…")
        #  Doesn't work without account service
        # self.driver.find_element(AppiumBy.NAME, "Initials")
        # self.driver.find_element(AppiumBy.NAME, "Placeholder Icon")


if __name__ == '__main__':
    unittest.main()
