// org.raye.quicksettings: the network, volume and battery pill of the Raye
// taskbar, and the quick settings panel it opens (click, or Win+A). The
// panel is a window of its own and is made the first time it opens: most
// sessions open it a few times at most.
import QtQuick
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.raye.shell

PlasmoidItem {
    id: root

    // the pill is the applet's only face: Plasma never builds a compact
    // representation for an applet that has no full one, so the pill is the
    // full representation and the panel is a window of its own
    preferredRepresentation: fullRepresentation
    activationTogglesExpanded: false
    Plasmoid.backgroundHints: PlasmaCore.Types.NoBackground
    Plasmoid.status: panelWindow.visible ? PlasmaCore.Types.RequiresAttentionStatus : PlasmaCore.Types.ActiveStatus
    // set up in Raye Settings, never in a Plasma dialog
    Plasmoid.hasConfigurationInterface: false
    toolTipMainText: ""
    toolTipSubText: ""

    readonly property var screenRect: Plasmoid.containment ? Plasmoid.containment.screenGeometry : Qt.rect(0, 0, 1280, 800)
    // the screen edge the panel is on
    readonly property string edge: BarEdge.of(Plasmoid.location, ShellSettings.position)
    readonly property bool vertical: BarEdge.vertical(edge)

    Backend { id: system }

    readonly property Item panel: panelLoader.item

    function panelTop() {
        const face = root.fullRepresentationItem
        return face && face.Window.window ? face.Window.window.y : screenRect.y + screenRect.height - ShellTokens.taskbarHeight
    }
    function place() {
        if (!panel)
            return
        if (root.edge !== "bottom") {
            // the cards, 12 px off the bar, at the far end of the screen
            const face = root.fullRepresentationItem
            const bar = face && face.Window.window ? (root.vertical ? face.Window.window.width : face.Window.window.height)
                                                   : ShellTokens.taskbarHeight
            const m = panel.margin
            const at = BarEdge.place(root.edge, screenRect, bar, 12, frame.width - 2 * m, frame.height - 2 * m, "end", null, 12)
            panelWindow.x = at.x - m
            panelWindow.y = at.y - m
            return
        }
        panelWindow.x = screenRect.x + screenRect.width - panel.width + panel.margin - 12
        panelWindow.y = Math.max(screenRect.y, panelTop() - 12 - frame.height + panel.margin)
    }
    function open() {
        panelLoader.active = true
        panel.shown = true
        place()
        panelWindow.visible = true
        panelWindow.requestActivate()
    }
    function close() {
        if (panelWindow.visible && panel)
            panel.shown = false
    }
    function toggle() {
        if (panelWindow.visible)
            close()
        else
            open()
    }

    GlobalShortcut {
        name: "raye-quick-settings"
        text: i18nd("raye_shell_quicksettings", "Open quick settings")
        sequence: "Meta+A"
        onActivated: root.toggle()
    }
    Connections {
        target: Plasmoid
        function onActivated() { root.toggle() }
    }

    PlasmaCore.Dialog {
        id: panelWindow
        location: PlasmaCore.Types.Floating
        type: PlasmaCore.Dialog.AppletPopup
        backgroundHints: PlasmaCore.Dialog.NoBackground
        hideOnWindowDeactivate: true
        visible: false
        onVisibleChanged: {
            if (!visible && root.panel)
                root.panel.shown = false
        }

        mainItem: PanelFrame {
            id: frame
            panel: panelLoader.item
            focus: true
            // only a new tallest page (edit mode, a player showing up)
            // resizes the window; a page change does not
            onHeightChanged: if (panelWindow.visible) root.place()
            onOutsideClicked: root.close()

            Loader {
                id: panelLoader
                // against the bar's side of the window: the tallest page grows away from it
                y: root.edge === "top" ? 0 : frame.height - height
                // without focus the panel never gets the keys of its
                // window, and Esc does not close it
                focus: true
                active: false
                sourceComponent: QuickPanel {
                    backend: system
                    edge: root.edge
                    onRequestClose: root.close()
                    onClosed: panelWindow.visible = false
                    onOpenSettings: page => Launcher.openSettings(page)
                    onLaunch: desktopId => Launcher.launch(desktopId)
                }
            }
        }
    }

    // right-click on the pill: the settings behind its three glyphs
    Loader {
        id: pillMenuLoader
        active: false
        sourceComponent: PanelMenu {
            RayeMenuItem {
                text: i18nd("raye_shell_quicksettings", "Network and internet settings")
                icon.name: "network-wired-symbolic"
                onTriggered: Launcher.openSettings("network")
            }
            RayeMenuItem {
                text: i18nd("raye_shell_quicksettings", "Sound settings")
                icon.name: "audio-volume-high-symbolic"
                onTriggered: Launcher.openSettings("system/sound")
            }
            RayeMenuItem {
                text: i18nd("raye_shell_quicksettings", "Power and battery settings")
                icon.name: "battery-080-symbolic"
                onTriggered: Launcher.openSettings("system/power")
            }
        }
    }

    fullRepresentation: Item {
        Layout.minimumWidth: root.vertical ? 0 : pill.implicitWidth
        Layout.preferredWidth: root.vertical ? -1 : pill.implicitWidth
        Layout.fillHeight: !root.vertical
        Layout.minimumHeight: root.vertical ? pill.implicitHeight : 0
        Layout.preferredHeight: root.vertical ? pill.implicitHeight : -1
        Layout.fillWidth: root.vertical
        implicitWidth: pill.implicitWidth
        implicitHeight: pill.implicitHeight

        QuickPill {
            id: pill
            vertical: root.vertical
            anchors.centerIn: parent
            backend: system
            selected: panelWindow.visible
            onClicked: root.toggle()

            MouseArea {
                anchors.fill: parent
                acceptedButtons: Qt.RightButton
                onClicked: mouse => {
                    pillMenuLoader.active = true
                    pillMenuLoader.item.open(pill, mouse.x)
                }
            }
        }
    }
}
