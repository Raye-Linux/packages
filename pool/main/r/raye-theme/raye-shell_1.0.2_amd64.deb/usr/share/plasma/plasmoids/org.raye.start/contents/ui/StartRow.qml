// The Start applet on the taskbar: the Raye eye, the search field or
// button (per the search style of Settings) and the Task view button.
// Each is a 40 x 40 backplate with 4 px corners; the search box is a
// 232 x 32 pill. `leadingSpace` is the room left before the eye so the
// whole group (these buttons and the apps after them) sits in the middle
// of the screen. In the Windows 10 look the buttons fill the taskbar's
// height side by side from the left edge, and the search box is a wide
// square field ("Type here to search").
import QtQuick
import QtQuick.Templates as T
import org.kde.kirigami as Kirigami
import org.raye.ui
import org.raye.shell

import "startlogic.js" as Logic

Item {
    id: row

    property var settings: ShellSettings
    property int leadingSpace: 0
    // the popup is open, in which mode
    property bool expanded: false
    property string mode: "start"

    readonly property bool windows10: settings.windows10 === true
    // the taskbar stands on a side of the screen: the buttons are stacked
    // from the top, and search is a button (a box does not fit)
    property bool vertical: ShellTokens.barVertical
    readonly property string searchStyle: {
        const s = Logic.searchStyle(settings.searchMode)
        if (vertical)
            return s === "hidden" ? s : "icon"
        return windows10 && s === "iconlabel" ? "box" : s
    }
    readonly property bool taskViewShown: settings.taskView
    readonly property int rowWidth: windows10 ? Logic.rowWidth10(searchStyle, taskViewShown)
                                              : Logic.rowWidth(searchStyle, taskViewShown)
    // a button of the row: 40 x 40, or the taskbar's height and 48 wide
    // stacked, a button fills the bar's width in the Windows 10 look
    readonly property int buttonWidth: vertical ? (windows10 ? width : Math.min(Logic.buttonSize, width - 8))
                                                : (windows10 ? Logic.w10.buttonWidth : Logic.buttonSize)
    readonly property int buttonHeight: vertical ? (windows10 ? Logic.w10.buttonWidth : Logic.buttonSize)
                                                 : (windows10 ? height : Math.min(Logic.buttonSize, height - 8))

    // Fitts: every button takes the clicks down to the screen's edge and
    // half way to the next one; left aligned, the eye has the corner
    readonly property real gapReach: windows10 ? 0 : Logic.buttonGap / 2
    readonly property real barReach: ShellTokens.taskbarHeight
    readonly property bool atLeftEdge: settings.alignment === "left"
    // the reach of a button across the bar (to the screen's edge) and along
    // it, and the eye's room before it at the start of the screen
    readonly property real acrossReach: barReach
    readonly property real leadReach: vertical || atLeftEdge ? leadingSpace + barReach : gapReach

    readonly property Item startButton: startButton
    readonly property Item taskViewButton: taskViewButton

    signal startClicked()
    signal searchClicked()
    signal taskViewClicked()
    signal taskViewHovered(bool hovered)
    // right-click on the eye: the quick link menu, at that point of the eye
    signal quickLinksRequested()
    // the quick link menu is open: no "Start" tooltip over it
    property bool quickLinksOpen: false

    implicitWidth: vertical ? ShellTokens.taskbarHeight : leadingSpace + rowWidth
    implicitHeight: vertical ? leadingSpace + rowWidth : ShellTokens.taskbarHeight
    Behavior on leadingSpace {
        NumberAnimation { duration: ShellTokens.durationNormal; easing: Motion.pointToPoint }
    }

    Grid {
        id: buttons
        objectName: "startButtons"
        x: row.vertical ? Math.round((row.width - width) / 2) : row.leadingSpace
        y: row.vertical ? row.leadingSpace : Math.round((row.height - height) / 2)
        // one row, or one column on a side
        // one column on a side, else one row (never both set, so no step between)
        columns: row.vertical ? 1 : 100
        verticalItemAlignment: Grid.AlignVCenter
        horizontalItemAlignment: Grid.AlignHCenter
        spacing: row.windows10 ? 0 : Logic.buttonGap

        // the Raye eye, which blinks when pressed
        PanelButton {
            id: startButton
            objectName: "startButton"
            width: row.buttonWidth
            height: row.buttonHeight
            reachLeft: row.vertical ? row.acrossReach : row.leadReach
            reachRight: row.vertical ? row.acrossReach : row.gapReach
            reachTop: row.vertical ? row.leadReach : row.barReach
            reachBottom: row.vertical ? row.gapReach : row.barReach
            selected: row.expanded && row.mode === "start"
            toolTipText: row.expanded || row.quickLinksOpen ? "" : i18nd("raye_shell_start", "Start")
            Accessible.role: Accessible.ButtonMenu

            function blink() {
                blinkAnimation.restart()
            }

            onPressed: blink()
            onClicked: row.startClicked()

            Kirigami.Icon {
                id: eye
                objectName: "eye"
                // 1 open, near 0 closed: the lid squeezes the eye from top and bottom
                property real lid: 1
                anchors.centerIn: parent
                // the eye is wide and flat: 32 wide gives it the weight of
                // a 24 px square glyph
                width: 32
                height: 32
                source: "raye-eye"
                transform: Scale {
                    origin.x: eye.width / 2
                    origin.y: eye.height / 2
                    yScale: eye.lid
                }

                SequentialAnimation {
                    id: blinkAnimation
                    NumberAnimation { target: eye; property: "lid"; to: 0.1; duration: ShellTokens.blinkClosed; easing.type: Easing.InQuad }
                    NumberAnimation { target: eye; property: "lid"; to: 1; duration: ShellTokens.blinkOpen; easing: Motion.entrance }
                }
            }

            TapHandler {
                acceptedButtons: Qt.RightButton
                onTapped: row.quickLinksRequested()
            }
        }

        T.AbstractButton {
            id: searchBox
            objectName: "searchBox"
            visible: row.searchStyle === "box"
            width: row.windows10 ? Logic.w10.searchBoxWidth : Logic.searchBoxWidth
            height: row.windows10 ? row.height : Logic.searchBoxHeight
            hoverEnabled: true
            focusPolicy: Qt.TabFocus
            containmentMask: EdgeReach {
                target: searchBox
                left: row.gapReach
                right: row.gapReach
                top: row.barReach
                bottom: row.barReach
            }
            Accessible.role: Accessible.EditableText
            Accessible.name: i18nd("raye_shell_start", "Search")
            onClicked: row.searchClicked()

            background: Rectangle {
                radius: row.windows10 ? 0 : height / 2
                color: row.windows10 ? (ShellTokens.taskbarDark ? Qt.rgba(1, 1, 1, searchBox.down ? 0.08 : searchBox.hovered ? 0.15 : 0.11)
                                                                : Qt.rgba(1, 1, 1, searchBox.hovered ? 0.95 : 0.85))
                     : ShellTokens.taskbarDark ? Qt.rgba(1, 1, 1, searchBox.down ? 0.04 : searchBox.hovered ? 0.08 : 0.05)
                                               : Qt.rgba(1, 1, 1, searchBox.hovered ? 0.7 : 0.55)
                border.width: 1
                border.color: row.expanded && row.mode === "search" ? Qt.alpha(ShellTokens.accent, 0.8)
                                                                     : ShellTokens.taskbarDark ? Qt.rgba(1, 1, 1, 0.1) : Qt.rgba(0, 0, 0, 0.08)
                Behavior on color { ColorAnimation { duration: ShellTokens.durationFaster } }
                FocusRing { radius: row.windows10 ? 0 : height / 2; target: searchBox }
            }

            contentItem: Item {
                SearchGlyph {
                    id: boxGlass
                    x: row.windows10 ? 14 : 12
                    anchors.verticalCenter: parent.verticalCenter
                    width: 16
                    height: 16
                    color: ShellTokens.taskbarText
                    tilted: searchBox.hovered
                }
                Text {
                    anchors { left: boxGlass.right; leftMargin: 10; right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
                    text: row.windows10 ? i18nd("raye_shell_start", "Type here to search") : i18nd("raye_shell_start", "Search")
                    elide: Text.ElideRight
                    color: Qt.alpha(ShellTokens.taskbarText, 0.72)
                    font.family: "Inter"
                    font.pixelSize: 14
                }
            }
        }

        PanelButton {
            id: searchLabel
            objectName: "searchLabel"
            reachLeft: row.vertical ? row.acrossReach : row.gapReach
            reachRight: row.vertical ? row.acrossReach : row.gapReach
            reachTop: row.vertical ? row.gapReach : row.barReach
            reachBottom: row.vertical ? row.gapReach : row.barReach
            visible: row.searchStyle === "iconlabel"
            width: Logic.searchLabelWidth
            selected: row.expanded && row.mode === "search"
            Accessible.name: i18nd("raye_shell_start", "Search")
            onClicked: row.searchClicked()

            Row {
                anchors.centerIn: parent
                spacing: 8
                SearchGlyph {
                    anchors.verticalCenter: parent.verticalCenter
                    width: 16
                    height: 16
                    color: ShellTokens.taskbarText
                    tilted: searchLabel.hovered
                }
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: i18nd("raye_shell_start", "Search")
                    color: ShellTokens.taskbarText
                    font: ShellTokens.caption
                    elide: Text.ElideRight
                    width: Math.min(implicitWidth, searchLabel.width - 44)
                }
            }
        }

        PanelButton {
            id: searchIcon
            objectName: "searchIcon"
            reachLeft: row.vertical ? row.acrossReach : row.gapReach
            reachRight: row.vertical ? row.acrossReach : row.gapReach
            reachTop: row.vertical ? row.gapReach : row.barReach
            reachBottom: row.vertical ? row.gapReach : row.barReach
            visible: row.searchStyle === "icon"
            width: row.buttonWidth
            height: row.buttonHeight
            selected: row.expanded && row.mode === "search"
            toolTipText: i18nd("raye_shell_start", "Search")
            onClicked: row.searchClicked()

            SearchGlyph {
                anchors.centerIn: parent
                width: 20
                height: 20
                color: ShellTokens.taskbarText
                tilted: searchIcon.hovered
            }
        }

        PanelButton {
            id: taskViewButton
            objectName: "taskViewButton"
            reachLeft: row.vertical ? row.acrossReach : row.gapReach
            reachRight: row.vertical ? row.acrossReach : row.gapReach
            reachTop: row.vertical ? row.gapReach : row.barReach
            reachBottom: row.vertical ? row.gapReach : row.barReach
            visible: row.taskViewShown
            width: row.buttonWidth
            height: row.buttonHeight
            toolTipText: i18nd("raye_shell_start", "Task view")
            onClicked: row.taskViewClicked()
            onHoveredChanged: row.taskViewHovered(hovered)

            TaskViewGlyph {
                anchors.centerIn: parent
                width: ShellTokens.iconSize
                height: ShellTokens.iconSize
                color: ShellTokens.taskbarText
                slide: taskViewButton.hovered ? 1.5 : 0
                Behavior on slide { NumberAnimation { duration: ShellTokens.durationFast; easing: Motion.pointToPoint } }
            }
        }
    }
}
