// Words of the sign-in screens, in English, French, Spanish, German,
// Brazilian Portuguese and Italian.
//
// No gettext: the SDDM greeter, the lock screen, the logout screen, the
// splash and the admin prompt all load this module, and some of them
// have no translation catalogue. The language follows the locale of the
// process (SDDM: /etc/default/locale; the others: the user's), or `lang`
// when an adapter or the gallery sets it.
//
// Use: Strings.tr.password, Strings.tr.verifiedPublisher.arg(name).
pragma Singleton

import QtQuick

QtObject {
    id: strings

    // "en", "fr", "es", "de", "pt_BR" or "it"; empty follows the locale
    property string lang: ""

    // The languages these screens are written in. Any other locale reads
    // English; Portuguese other than Brazil's reads Brazil's.
    readonly property var languages: ["en", "fr", "es", "de", "pt_BR", "it"]
    function languageOf(name) {
        name = String(name)
        for (var i = 0; i < languages.length; ++i)
            if (name.indexOf(languages[i].split("_")[0]) === 0)
                return languages[i]
        return "en"
    }
    readonly property string language: lang !== "" ? lang : languageOf(Qt.locale().name)
    readonly property var mainRegion: ({ en: "en_US", fr: "fr_FR", es: "es_ES", de: "de_DE", pt_BR: "pt_BR", it: "it_IT" })

    // Date and time formats follow the region when the language is the
    // locale's own; a forced language uses its main region.
    readonly property var locale: {
        var own = Qt.locale()
        if (own.name.indexOf(language) === 0)
            return own
        return Qt.locale(mainRegion[language] || "en_US")
    }

    // a key a language lacks reads English
    readonly property var tr: Object.assign({}, en, strings[language] || {})

    // The clock of the lock view: the region's short time, without the
    // seconds and without a time zone, and for the rest exactly as the
    // region writes it -- its AM/PM marker included, where the region puts
    // it (Korean puts it in front of the digits, so it cannot simply be
    // appended).
    //
    // The marker used to be taken off the rendered time. It cannot be: in
    // Qt, `h` and `hh` count 1 to 12 as soon as AP is in the format, and
    // only `H`/`HH` always count 0 to 23. Without its marker a 12-hour
    // region therefore read the same at 3 in the morning and at 3 in the
    // afternoon -- measured on 52 of the 189 regions Qt carries here,
    // en_US and en_CA among them. A 24-hour region has no AP in its short
    // format, so it gains no marker: nothing is added below, the region's
    // own format decides. tst_strings sweeps the regions for this.
    function clockFormat(loc) {
        var f = loc.timeFormat(Locale.ShortFormat)
        f = f.replace(/[:.]ss/g, "")
        f = f.replace(/\s*t+\s*/g, " ")
        return f.trim()
    }

    function timeText(date, loc) {
        loc = loc || locale
        // Some regions separate the time from its marker with a narrow
        // no-break space; the display font of the clock wants a plain one.
        var text = loc.toString(date, clockFormat(loc)).replace(/[\s\u202f]+/g, " ").trim()
        // The taskbar always writes AM and PM. Some regions spell the same
        // marker "p.m." or "p. m.": read one way on the bar and another on
        // the lock screen. Other scripts keep their own word.
        return text.replace(/(^|\s)([ap])\.?\s?m\.?(?=\s|$)/i,
                            (all, before, letter) => before + letter.toUpperCase() + "M")
    }

    // "Wednesday, October 29" / "mercredi 29 octobre": the region's long
    // date without the year.
    function dateFormat(loc) {
        var f = loc.dateFormat(Locale.LongFormat)
        f = f.replace(/[\s,.\/-]*y+[.]?/g, "")
        f = f.replace(/^[\s,]+|[\s,]+$/g, "")
        return f
    }

    function dateText(date, loc) {
        loc = loc || locale
        return loc.toString(date, dateFormat(loc))
    }

    readonly property var en: ({
        password: "Password",
        signIn: "Sign in",
        showPassword: "Show password",
        hidePassword: "Hide password",
        capsLock: "Caps Lock is on",
        wrongPassword: "The password is incorrect. Try again.",
        ok: "OK",
        welcome: "Welcome",
        signingOut: "Signing out",
        shuttingDown: "Shutting down",
        restarting: "Restarting",
        workingOnUpdates: "Working on updates",
        percent: "%1%",
        dontTurnOff: "Don't turn off your PC",
        hi: "Hi",
        gettingReady: "We're getting things ready",
        mightTakeMinute: "This might take a minute",
        pressKey: "Press a key or click to sign in",
        power: "Power",
        sleep: "Sleep",
        hibernate: "Hibernate",
        shutDown: "Shut down",
        restart: "Restart",
        updateAndShutDown: "Update and shut down",
        updateAndRestart: "Update and restart",
        accessibility: "Accessibility",
        onScreenKeyboard: "On-screen keyboard",
        largerText: "Larger text",
        highContrast: "High contrast",
        network: "Network",
        networkSignIn: "Sign in to connect to a network",
        connected: "Connected",
        notConnected: "Not connected",
        keyboardLayout: "Keyboard layout",
        signInOptions: "Sign-in options",
        switchUser: "Switch user",
        otherUsers: "Other users",
        fingerprint: "Scan your finger on the fingerprint reader",
        lock: "Lock",
        signOut: "Sign out",
        changePassword: "Change a password",
        changePasswordElsewhere: "A password is changed in Settings, not from this screen.",
        taskManager: "Task Manager",
        taskManagerMissing: "Task Manager is not installed.",
        cancel: "Cancel",
        emergencyRestart: "Emergency restart",
        emergencyWarning: "Click OK to restart right away. Any unsaved data will be lost.",
        rootAccess: "Root access needed",
        allowChanges: "Do you want to allow this app to make changes to your device?",
        verifiedPublisher: "Verified publisher: %1",
        fileOrigin: "File origin: This computer",
        unknownPublisher: "Publisher: Unknown",
        showDetails: "Show more details",
        hideDetails: "Hide details",
        enterOwnPassword: "Enter your password to continue as root.",
        enterSudoPassword: "To continue as root, enter the password of a sudo user.",
        moreChoices: "More choices",
        yes: "Yes",
        no: "No",
        pleaseWait: "Please wait",
        desktop: "Desktop",
        desktopNamed: "Desktop: %1",
        sessionPlasma: "Raye",
        sessionHyprland: "Raye (Hyprland)"
    })

    readonly property var fr: ({
        password: "Mot de passe",
        signIn: "Se connecter",
        showPassword: "Afficher le mot de passe",
        hidePassword: "Masquer le mot de passe",
        capsLock: "Verr. Maj. activé",
        wrongPassword: "Le mot de passe est incorrect. Réessayez.",
        ok: "OK",
        welcome: "Bienvenue",
        signingOut: "Déconnexion",
        shuttingDown: "Arrêt en cours",
        restarting: "Redémarrage",
        workingOnUpdates: "Mises à jour en cours",
        percent: "%1 %",
        dontTurnOff: "N'éteignez pas votre PC",
        hi: "Bonjour",
        gettingReady: "Nous préparons tout pour vous",
        mightTakeMinute: "Cela peut prendre une minute",
        pressKey: "Appuyez sur une touche ou cliquez pour vous connecter",
        power: "Alimentation",
        sleep: "Mettre en veille",
        hibernate: "Mettre en veille prolongée",
        shutDown: "Arrêter",
        restart: "Redémarrer",
        updateAndShutDown: "Mettre à jour et arrêter",
        updateAndRestart: "Mettre à jour et redémarrer",
        accessibility: "Accessibilité",
        onScreenKeyboard: "Clavier visuel",
        largerText: "Texte plus grand",
        highContrast: "Contraste élevé",
        network: "Réseau",
        networkSignIn: "Connectez-vous pour rejoindre un réseau",
        connected: "Connecté",
        notConnected: "Non connecté",
        keyboardLayout: "Disposition du clavier",
        signInOptions: "Options de connexion",
        switchUser: "Changer d'utilisateur",
        otherUsers: "Autres utilisateurs",
        fingerprint: "Posez votre doigt sur le lecteur d'empreintes",
        lock: "Verrouiller",
        signOut: "Se déconnecter",
        changePassword: "Modifier un mot de passe",
        changePasswordElsewhere: "Un mot de passe se modifie dans les Paramètres, pas depuis cet écran.",
        taskManager: "Gestionnaire des tâches",
        taskManagerMissing: "Le Gestionnaire des tâches n'est pas installé.",
        cancel: "Annuler",
        emergencyRestart: "Redémarrage d'urgence",
        emergencyWarning: "Cliquez sur OK pour redémarrer immédiatement. Toutes les données non enregistrées seront perdues.",
        rootAccess: "Accès root requis",
        allowChanges: "Voulez-vous autoriser cette application à apporter des modifications à votre appareil ?",
        verifiedPublisher: "Éditeur vérifié : %1",
        fileOrigin: "Origine du fichier : cet ordinateur",
        unknownPublisher: "Éditeur : inconnu",
        showDetails: "Afficher plus de détails",
        hideDetails: "Masquer les détails",
        enterOwnPassword: "Entrez votre mot de passe pour continuer en tant que root.",
        enterSudoPassword: "Pour continuer en tant que root, entrez le mot de passe d'un utilisateur sudo.",
        moreChoices: "Plus de choix",
        yes: "Oui",
        no: "Non",
        pleaseWait: "Veuillez patienter",
        desktop: "Bureau",
        desktopNamed: "Bureau : %1",
        sessionPlasma: "Raye",
        sessionHyprland: "Raye (Hyprland)"
    })

    readonly property var es: ({
        password: "Contraseña",
        signIn: "Iniciar sesión",
        showPassword: "Mostrar contraseña",
        hidePassword: "Ocultar contraseña",
        capsLock: "Bloq Mayús está activado",
        wrongPassword: "La contraseña no es correcta. Inténtalo de nuevo.",
        ok: "Aceptar",
        welcome: "Te damos la bienvenida",
        signingOut: "Cerrando sesión",
        shuttingDown: "Apagando",
        restarting: "Reiniciando",
        workingOnUpdates: "Trabajando en las actualizaciones",
        percent: "%1 %",
        dontTurnOff: "No apagues el PC",
        hi: "Hola",
        gettingReady: "Estamos preparando todo",
        mightTakeMinute: "Esto puede tardar un minuto",
        pressKey: "Presiona una tecla o haz clic para iniciar sesión",
        power: "Inicio/apagado",
        sleep: "Suspender",
        hibernate: "Hibernar",
        shutDown: "Apagar",
        restart: "Reiniciar",
        updateAndShutDown: "Actualizar y apagar",
        updateAndRestart: "Actualizar y reiniciar",
        accessibility: "Accesibilidad",
        onScreenKeyboard: "Teclado en pantalla",
        largerText: "Texto más grande",
        highContrast: "Contraste alto",
        network: "Red",
        networkSignIn: "Inicia sesión para conectarte a una red",
        connected: "Conectado",
        notConnected: "No conectado",
        keyboardLayout: "Distribución del teclado",
        signInOptions: "Opciones de inicio de sesión",
        switchUser: "Cambiar de usuario",
        otherUsers: "Otros usuarios",
        fingerprint: "Coloca el dedo en el lector de huellas digitales",
        lock: "Bloquear",
        signOut: "Cerrar sesión",
        changePassword: "Cambiar una contraseña",
        changePasswordElsewhere: "Las contraseñas se cambian en Configuración, no desde esta pantalla.",
        taskManager: "Administrador de tareas",
        taskManagerMissing: "El Administrador de tareas no está instalado.",
        cancel: "Cancelar",
        emergencyRestart: "Reinicio de emergencia",
        emergencyWarning: "Haz clic en Aceptar para reiniciar ahora. Se perderán los datos no guardados.",
        rootAccess: "Se necesita acceso root",
        allowChanges: "¿Quieres permitir que esta aplicación haga cambios en el dispositivo?",
        verifiedPublisher: "Editor comprobado: %1",
        fileOrigin: "Origen del archivo: este equipo",
        unknownPublisher: "Editor: desconocido",
        showDetails: "Mostrar más detalles",
        hideDetails: "Ocultar detalles",
        enterOwnPassword: "Escribe tu contraseña para continuar como root.",
        enterSudoPassword: "Para continuar como root, escribe la contraseña de un usuario sudo.",
        moreChoices: "Más opciones",
        yes: "Sí",
        no: "No",
        pleaseWait: "Espera",
        desktop: "Escritorio",
        desktopNamed: "Escritorio: %1",
        sessionPlasma: "Raye",
        sessionHyprland: "Raye (Hyprland)"
    })

    readonly property var de: ({
        password: "Kennwort",
        signIn: "Anmelden",
        showPassword: "Kennwort anzeigen",
        hidePassword: "Kennwort ausblenden",
        capsLock: "Feststelltaste ist aktiviert",
        wrongPassword: "Das Kennwort ist falsch. Versuchen Sie es erneut.",
        ok: "OK",
        welcome: "Willkommen",
        signingOut: "Abmelden",
        shuttingDown: "Herunterfahren",
        restarting: "Neustart",
        workingOnUpdates: "Updates werden bearbeitet",
        percent: "%1 %",
        dontTurnOff: "Schalten Sie den PC nicht aus",
        hi: "Hallo",
        gettingReady: "Alles wird vorbereitet",
        mightTakeMinute: "Dies kann eine Minute dauern",
        pressKey: "Drücken Sie eine Taste oder klicken Sie, um sich anzumelden",
        power: "Ein/Aus",
        sleep: "Energie sparen",
        hibernate: "Ruhezustand",
        shutDown: "Herunterfahren",
        restart: "Neu starten",
        updateAndShutDown: "Aktualisieren und herunterfahren",
        updateAndRestart: "Aktualisieren und neu starten",
        accessibility: "Barrierefreiheit",
        onScreenKeyboard: "Bildschirmtastatur",
        largerText: "Größerer Text",
        highContrast: "Hoher Kontrast",
        network: "Netzwerk",
        networkSignIn: "Melden Sie sich an, um eine Verbindung mit einem Netzwerk herzustellen",
        connected: "Verbunden",
        notConnected: "Nicht verbunden",
        keyboardLayout: "Tastaturlayout",
        signInOptions: "Anmeldeoptionen",
        switchUser: "Benutzer wechseln",
        otherUsers: "Andere Benutzer",
        fingerprint: "Legen Sie Ihren Finger auf den Fingerabdruckleser",
        lock: "Sperren",
        signOut: "Abmelden",
        changePassword: "Kennwort ändern",
        changePasswordElsewhere: "Kennwörter werden in den Einstellungen geändert, nicht auf diesem Bildschirm.",
        taskManager: "Task-Manager",
        taskManagerMissing: "Der Task-Manager ist nicht installiert.",
        cancel: "Abbrechen",
        emergencyRestart: "Notfallneustart",
        emergencyWarning: "Klicken Sie auf OK, um sofort neu zu starten. Nicht gespeicherte Daten gehen verloren.",
        rootAccess: "Root-Zugriff erforderlich",
        allowChanges: "Möchten Sie zulassen, dass durch diese App Änderungen an Ihrem Gerät vorgenommen werden?",
        verifiedPublisher: "Verifizierter Herausgeber: %1",
        fileOrigin: "Dateiursprung: Dieser Computer",
        unknownPublisher: "Herausgeber: Unbekannt",
        showDetails: "Weitere Details anzeigen",
        hideDetails: "Details ausblenden",
        enterOwnPassword: "Geben Sie Ihr Kennwort ein, um als root fortzufahren.",
        enterSudoPassword: "Geben Sie das Kennwort eines sudo-Benutzers ein, um als root fortzufahren.",
        moreChoices: "Weitere Optionen",
        yes: "Ja",
        no: "Nein",
        pleaseWait: "Bitte warten",
        desktop: "Desktop",
        desktopNamed: "Desktop: %1",
        sessionPlasma: "Raye",
        sessionHyprland: "Raye (Hyprland)"
    })

    readonly property var pt_BR: ({
        password: "Senha",
        signIn: "Entrar",
        showPassword: "Mostrar senha",
        hidePassword: "Ocultar senha",
        capsLock: "Caps Lock está ativado",
        wrongPassword: "A senha está incorreta. Tente novamente.",
        ok: "OK",
        welcome: "Bem-vindo(a)",
        signingOut: "Saindo",
        shuttingDown: "Desligando",
        restarting: "Reiniciando",
        workingOnUpdates: "Trabalhando nas atualizações",
        percent: "%1%",
        dontTurnOff: "Não desligue o PC",
        hi: "Olá",
        gettingReady: "Estamos preparando tudo",
        mightTakeMinute: "Isso pode levar um minuto",
        pressKey: "Pressione uma tecla ou clique para entrar",
        power: "Ligar/Desligar",
        sleep: "Suspender",
        hibernate: "Hibernar",
        shutDown: "Desligar",
        restart: "Reiniciar",
        updateAndShutDown: "Atualizar e desligar",
        updateAndRestart: "Atualizar e reiniciar",
        accessibility: "Acessibilidade",
        onScreenKeyboard: "Teclado virtual",
        largerText: "Texto maior",
        highContrast: "Alto contraste",
        network: "Rede",
        networkSignIn: "Entre para se conectar a uma rede",
        connected: "Conectado",
        notConnected: "Não conectado",
        keyboardLayout: "Layout do teclado",
        signInOptions: "Opções de entrada",
        switchUser: "Trocar de usuário",
        otherUsers: "Outros usuários",
        fingerprint: "Toque o leitor de impressão digital com o dedo",
        lock: "Bloquear",
        signOut: "Sair",
        changePassword: "Alterar uma senha",
        changePasswordElsewhere: "A senha é alterada em Configurações, não nesta tela.",
        taskManager: "Gerenciador de Tarefas",
        taskManagerMissing: "O Gerenciador de Tarefas não está instalado.",
        cancel: "Cancelar",
        emergencyRestart: "Reinício de emergência",
        emergencyWarning: "Clique em OK para reiniciar agora. Os dados não salvos serão perdidos.",
        rootAccess: "Acesso root necessário",
        allowChanges: "Deseja permitir que este aplicativo faça alterações no seu dispositivo?",
        verifiedPublisher: "Editor verificado: %1",
        fileOrigin: "Origem do arquivo: este computador",
        unknownPublisher: "Editor: desconhecido",
        showDetails: "Mostrar mais detalhes",
        hideDetails: "Ocultar detalhes",
        enterOwnPassword: "Insira sua senha para continuar como root.",
        enterSudoPassword: "Para continuar como root, insira a senha de um usuário sudo.",
        moreChoices: "Mais opções",
        yes: "Sim",
        no: "Não",
        pleaseWait: "Aguarde",
        desktop: "Área de Trabalho",
        desktopNamed: "Área de Trabalho: %1",
        sessionPlasma: "Raye",
        sessionHyprland: "Raye (Hyprland)"
    })

    readonly property var it: ({
        password: "Password",
        signIn: "Accedi",
        showPassword: "Mostra password",
        hidePassword: "Nascondi password",
        capsLock: "BLOC MAIUSC è attivo",
        wrongPassword: "La password non è corretta. Riprova.",
        ok: "OK",
        welcome: "Ti diamo il benvenuto",
        signingOut: "Disconnessione",
        shuttingDown: "Arresto in corso",
        restarting: "Riavvio in corso",
        workingOnUpdates: "Aggiornamenti in corso",
        percent: "%1%",
        dontTurnOff: "Non spegnere il PC",
        hi: "Ciao",
        gettingReady: "Stiamo preparando tutto",
        mightTakeMinute: "Potrebbe volerci un minuto",
        pressKey: "Premi un tasto o fai clic per accedere",
        power: "Arresta",
        sleep: "Sospendi",
        hibernate: "Iberna",
        shutDown: "Arresta il sistema",
        restart: "Riavvia il sistema",
        updateAndShutDown: "Aggiorna e arresta",
        updateAndRestart: "Aggiorna e riavvia",
        accessibility: "Accessibilità",
        onScreenKeyboard: "Tastiera su schermo",
        largerText: "Testo più grande",
        highContrast: "Contrasto elevato",
        network: "Rete",
        networkSignIn: "Accedi per connetterti a una rete",
        connected: "Connesso",
        notConnected: "Non connesso",
        keyboardLayout: "Layout di tastiera",
        signInOptions: "Opzioni di accesso",
        switchUser: "Cambia utente",
        otherUsers: "Altri utenti",
        fingerprint: "Appoggia il dito sul lettore di impronte digitali",
        lock: "Blocca",
        signOut: "Disconnetti",
        changePassword: "Cambia una password",
        changePasswordElsewhere: "La password si cambia in Impostazioni, non da questa schermata.",
        taskManager: "Gestione attività",
        taskManagerMissing: "Gestione attività non è installato.",
        cancel: "Annulla",
        emergencyRestart: "Riavvio di emergenza",
        emergencyWarning: "Fai clic su OK per riavviare subito. I dati non salvati andranno persi.",
        rootAccess: "Accesso root necessario",
        allowChanges: "Vuoi consentire a questa app di apportare modifiche al dispositivo?",
        verifiedPublisher: "Autore verificato: %1",
        fileOrigin: "Origine file: questo computer",
        unknownPublisher: "Autore: sconosciuto",
        showDetails: "Mostra altri dettagli",
        hideDetails: "Nascondi dettagli",
        enterOwnPassword: "Immetti la tua password per continuare come root.",
        enterSudoPassword: "Per continuare come root, immetti la password di un utente sudo.",
        moreChoices: "Altre opzioni",
        yes: "Sì",
        no: "No",
        pleaseWait: "Attendi",
        desktop: "Desktop",
        desktopNamed: "Desktop: %1",
        sessionPlasma: "Raye",
        sessionHyprland: "Raye (Hyprland)"
    })
}
